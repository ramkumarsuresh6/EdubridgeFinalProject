package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaptopBackend1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
